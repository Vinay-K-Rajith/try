import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStudentSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all students
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  // Get student by ID
  app.get("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const student = await storage.getStudent(id);
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  // Create new student
  app.post("/api/students", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      res.status(400).json({ message: "Invalid student data" });
    }
  });

  // Generate sample students
  app.post("/api/students/generate/:count", async (req, res) => {
    try {
      const count = parseInt(req.params.count);
      if (count <= 0 || count > 1000) {
        return res.status(400).json({ message: "Count must be between 1 and 1000" });
      }
      
      const students = await storage.generateSampleStudents(count);
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate sample students" });
    }
  });

  // Get dashboard analytics
  app.get("/api/analytics", async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      
      const totalLeads = students.length;
      const hotLeads = students.filter(s => s.leadCategory === "Hot Lead").length;
      const warmLeads = students.filter(s => s.leadCategory === "Warm Lead").length;
      const coldLeads = students.filter(s => s.leadCategory === "Cold Lead").length;
      
      // Score distribution
      const scoreRanges = {
        "90-100": 0,
        "80-89": 0,
        "70-79": 0,
        "60-69": 0,
        "50-59": 0,
        "0-49": 0
      };
      
      students.forEach(student => {
        const score = parseFloat(student.leadScore);
        if (score >= 90) scoreRanges["90-100"]++;
        else if (score >= 80) scoreRanges["80-89"]++;
        else if (score >= 70) scoreRanges["70-79"]++;
        else if (score >= 60) scoreRanges["60-69"]++;
        else if (score >= 50) scoreRanges["50-59"]++;
        else scoreRanges["0-49"]++;
      });
      
      // Class distribution
      const classDistribution: Record<string, number> = {};
      students.forEach(student => {
        classDistribution[student.classAppliedFor] = (classDistribution[student.classAppliedFor] || 0) + 1;
      });
      
      res.json({
        totalLeads,
        hotLeads,
        warmLeads,
        coldLeads,
        scoreDistribution: scoreRanges,
        classDistribution,
        averageScore: students.reduce((sum, s) => sum + parseFloat(s.leadScore), 0) / students.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
