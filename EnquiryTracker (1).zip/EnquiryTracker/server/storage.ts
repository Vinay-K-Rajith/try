import { users, students, type User, type InsertUser, type Student, type InsertStudent } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllStudents(): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  generateSampleStudents(count: number): Promise<Student[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private students: Map<number, Student>;
  private currentUserId: number;
  private currentStudentId: number;

  constructor() {
    this.users = new Map();
    this.students = new Map();
    this.currentUserId = 1;
    this.currentStudentId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllStudents(): Promise<Student[]> {
    return Array.from(this.students.values()).sort((a, b) => 
      new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime()
    );
  }

  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this.currentStudentId++;
    const student: Student = { 
      ...insertStudent, 
      id,
      lastClassPercentage: insertStudent.lastClassPercentage ?? null
    };
    this.students.set(id, student);
    return student;
  }

  async generateSampleStudents(count: number): Promise<Student[]> {
    const students: Student[] = [];
    
    const firstNames = [
      "Aarav", "Aditi", "Arjun", "Ananya", "Ishaan", "Kavya", "Rohan", "Priya",
      "Vivaan", "Diya", "Aditya", "Siya", "Karan", "Riya", "Vihaan", "Asha",
      "Aryan", "Meera", "Reyansh", "Tara", "Ayaan", "Neha", "Rudra", "Pooja",
      "Shivansh", "Shreya", "Arnav", "Khushi", "Kabir", "Nisha", "Devansh", "Ritika",
    ];

    const lastNames = [
      "Sharma", "Gupta", "Singh", "Kumar", "Patel", "Shah", "Agarwal", "Bansal",
      "Jain", "Mittal", "Agrawal", "Chopra", "Malhotra", "Arora", "Kapoor", "Mehta",
      "Verma", "Pandey", "Saxena", "Goyal", "Sinha", "Yadav", "Mishra", "Tiwari",
    ];

    const locations = [
      { name: "Connaught Place", score: 95 },
      { name: "Karol Bagh", score: 85 },
      { name: "Lajpat Nagar", score: 80 },
      { name: "Rajouri Garden", score: 75 },
      { name: "Dwarka", score: 70 },
      { name: "Rohini", score: 65 },
      { name: "Janakpuri", score: 80 },
      { name: "Vasant Kunj", score: 85 },
      { name: "Saket", score: 90 },
      { name: "Greater Kailash", score: 95 },
    ];

    const knowUsSources = [
      { name: "Current Parent Referral", score: 95 },
      { name: "Alumni Referral", score: 90 },
      { name: "Teacher Referral", score: 88 },
      { name: "Friend Referral", score: 85 },
      { name: "Educational Fair", score: 75 },
      { name: "Social Media", score: 70 },
      { name: "Google Search", score: 65 },
      { name: "School Website", score: 60 },
      { name: "Walk-in", score: 40 },
    ];

    const previousSchools = [
      { name: "Delhi Public School", score: 90 },
      { name: "Ryan International", score: 80 },
      { name: "DAV Public School", score: 75 },
      { name: "St. Mary's Convent", score: 85 },
      { name: "Modern School", score: 90 },
      { name: "Kendriya Vidyalaya", score: 70 },
      { name: "Little Angels School", score: 60 },
    ];

    const classes = [
      { name: "Nursery", score: 70 },
      { name: "LKG", score: 75 },
      { name: "UKG", score: 80 },
      { name: "Class 1", score: 85 },
      { name: "Class 6", score: 85 },
      { name: "Class 9", score: 90 },
      { name: "Class 11", score: 95 },
    ];

    for (let i = 0; i < count; i++) {
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const studentName = `${firstName} ${lastName}`;
      
      const location = locations[Math.floor(Math.random() * locations.length)];
      const locationScore = Math.max(0, Math.min(100, location.score + Math.floor(Math.random() * 21) - 10));
      
      const source = knowUsSources[Math.floor(Math.random() * knowUsSources.length)];
      const howYouKnowUsScore = Math.max(0, Math.min(100, source.score + Math.floor(Math.random() * 16) - 5));
      
      const hasSibling = Math.random() < 0.3;
      const siblingScore = hasSibling ? 100 : Math.floor(Math.random() * 21);
      
      const school = previousSchools[Math.floor(Math.random() * previousSchools.length)];
      const previousSchoolScore = Math.max(0, Math.min(100, school.score + Math.floor(Math.random() * 16) - 5));
      
      const classInfo = classes[Math.floor(Math.random() * classes.length)];
      const classScore = Math.max(0, Math.min(100, classInfo.score + Math.floor(Math.random() * 16) - 5));
      
      const isEarlyClass = ["Nursery", "LKG", "UKG"].includes(classInfo.name);
      const percentage = isEarlyClass ? null : Math.floor(Math.random() * 34) + 65;
      const percentageScore = isEarlyClass ? 
        Math.floor(Math.random() * 31) + 70 : 
        (percentage && percentage >= 90) ? 95 : (percentage && percentage >= 80) ? 80 : (percentage && percentage >= 70) ? 65 : 40;
      
      const emailDifferent = Math.random() < 0.2;
      const emailScore = emailDifferent ? Math.floor(Math.random() * 41) + 60 : 0;
      
      const whatsappDifferent = Math.random() < 0.25;
      const whatsappScore = whatsappDifferent ? Math.floor(Math.random() * 51) + 50 : 0;
      
      const leadScore = this.calculateLeadScore(
        locationScore, howYouKnowUsScore, siblingScore, previousSchoolScore,
        classScore, percentageScore, emailScore, whatsappScore
      );
      
      const leadCategory = this.categorizeLeadScore(leadScore);
      
      const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}@gmail.com`;
      const phone = `+91-${Math.floor(Math.random() * 1000000000) + 7000000000}`;
      
      const daysAgo = Math.floor(Math.random() * 60) + 1;
      const applicationDate = new Date();
      applicationDate.setDate(applicationDate.getDate() - daysAgo);
      
      const student = await this.createStudent({
        studentName,
        email,
        phone,
        location: location.name,
        locationScore,
        howYouKnowUs: source.name,
        howYouKnowUsScore,
        hasSiblingInSchool: hasSibling,
        siblingInSchoolScore: siblingScore,
        previousSchoolName: school.name,
        previousSchoolNameScore: previousSchoolScore,
        classAppliedFor: classInfo.name,
        classAppliedForScore: classScore,
        lastClassPercentage: percentage !== null ? `${percentage}%` : "N/A",
        lastClassPercentageScore: percentageScore,
        communicationEmailDifferent: emailDifferent,
        communicationEmailDifferentScore: emailScore,
        whatsappNumberDifferent: whatsappDifferent,
        whatsappNumberDifferentScore: whatsappScore,
        leadScore: leadScore.toString(),
        leadCategory,
        applicationDate,
      });
      
      students.push(student);
    }
    
    return students;
  }

  private calculateLeadScore(
    locationScore: number, howYouKnowUsScore: number, siblingScore: number,
    previousSchoolScore: number, classScore: number, percentageScore: number,
    emailScore: number, whatsappScore: number
  ): number {
    const weights = [0.85, 0.70, 0.95, 0.55, 0.50, 0.25, 0.25, 0.20];
    const scores = [
      locationScore, howYouKnowUsScore, siblingScore, previousSchoolScore,
      classScore, percentageScore, emailScore, whatsappScore
    ];
    
    const weightedSum = scores.reduce((sum, score, index) => sum + score * weights[index], 0);
    const totalWeights = weights.reduce((sum, weight) => sum + weight, 0);
    
    return Math.round((weightedSum / totalWeights + 5) * 100) / 100;
  }

  private categorizeLeadScore(score: number): string {
    if (score >= 80) return "Hot Lead";
    if (score >= 60) return "Warm Lead";
    return "Cold Lead";
  }

  private async initializeSampleData(): Promise<void> {
    // Generate initial sample data
    await this.generateSampleStudents(150);
  }
}

export const storage = new MemStorage();
