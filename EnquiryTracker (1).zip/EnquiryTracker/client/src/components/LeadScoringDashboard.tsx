import { useQuery } from "@tanstack/react-query";
import { School } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MetricsGrid from "./MetricsGrid";
import ChartsSection from "./ChartsSection";
import FiltersSection from "./FiltersSection";
import DataTable from "./DataTable";
import IndividualScoring from "./IndividualScoring";
import { Student } from "@shared/schema";
import { useState } from "react";

interface Analytics {
  totalLeads: number;
  hotLeads: number;
  warmLeads: number;
  coldLeads: number;
  scoreDistribution: Record<string, number>;
  classDistribution: Record<string, number>;
  averageScore: number;
}

export default function LeadScoringDashboard() {
  const [filters, setFilters] = useState({
    search: "",
    category: "",
    class: "",
    scoreRange: ""
  });

  const { data: students = [], isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"]
  });

  const { data: analytics, isLoading: analyticsLoading } = useQuery<Analytics>({
    queryKey: ["/api/analytics"]
  });

  const filteredStudents = students.filter(student => {
    const matchesSearch = !filters.search || 
      student.studentName.toLowerCase().includes(filters.search.toLowerCase()) ||
      student.email.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesCategory = !filters.category || 
      student.leadCategory.toLowerCase().includes(filters.category.toLowerCase());
    
    const matchesClass = !filters.class || 
      student.classAppliedFor.toLowerCase().includes(filters.class.toLowerCase());
    
    const matchesScoreRange = !filters.scoreRange || (() => {
      const score = parseFloat(student.leadScore);
      switch (filters.scoreRange) {
        case "90-100": return score >= 90;
        case "80-89": return score >= 80 && score < 90;
        case "70-79": return score >= 70 && score < 80;
        case "60-69": return score >= 60 && score < 70;
        case "0-59": return score < 60;
        default: return true;
      }
    })();
    
    return matchesSearch && matchesCategory && matchesClass && matchesScoreRange;
  });

  if (studentsLoading || analyticsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Header Section */}
      <div className="header">
        <h1 className="header-title">
          <School className="header-icon" />
          ENTAB Lead Scoring System
        </h1>
        <p className="header-subtitle">
          Intelligent student enrollment prediction & analysis dashboard
        </p>
      </div>

      <Tabs defaultValue="analytics" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="analytics">📊 Analytics Dashboard</TabsTrigger>
          <TabsTrigger value="individual">🎯 Individual Scoring</TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="space-y-6">
          {/* Key Metrics */}
          <MetricsGrid analytics={analytics} />

          {/* Charts Section */}
          <ChartsSection analytics={analytics} />

          {/* Filters */}
          <FiltersSection filters={filters} onFiltersChange={setFilters} />

          {/* Data Table */}
          <DataTable 
            students={filteredStudents} 
            totalStudents={students.length}
            filteredCount={filteredStudents.length}
          />
        </TabsContent>

        <TabsContent value="individual">
          <IndividualScoring />
        </TabsContent>
      </Tabs>
    </div>
  );
}
