import { Grid, Card, CardContent, Typography, Box, Avatar } from '@mui/material';
import { People, Whatshot, TrendingUp, AcUnit } from '@mui/icons-material';

interface Analytics {
  totalLeads: number;
  hotLeads: number;
  warmLeads: number;
  coldLeads: number;
  scoreDistribution: Record<string, number>;
  classDistribution: Record<string, number>;
  averageScore: number;
}

interface MetricsGridProps {
  analytics?: Analytics;
}

export default function MetricsGrid({ analytics }: MetricsGridProps) {
  if (!analytics) return null;

  const metrics = [
    {
      value: analytics.totalLeads,
      label: "Total Leads",
      icon: People,
      color: "#1976d2",
      bgColor: "#e3f2fd"
    },
    {
      value: analytics.hotLeads,
      label: "Hot Leads (≥80)",
      icon: Whatshot,
      color: "#d32f2f",
      bgColor: "#ffebee"
    },
    {
      value: analytics.warmLeads,
      label: "Warm Leads (60-79)",
      icon: TrendingUp,
      color: "#ed6c02",
      bgColor: "#fff3e0"
    },
    {
      value: analytics.coldLeads,
      label: "Cold Leads (<60)",
      icon: AcUnit,
      color: "#0288d1",
      bgColor: "#e1f5fe"
    }
  ];

  return (
    <Grid container spacing={3} sx={{ mb: 4 }}>
      {metrics.map((metric, index) => {
        const IconComponent = metric.icon;
        return (
          <Grid key={index} xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ p: 3 }}>
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Box>
                    <Typography variant="h4" component="div" fontWeight="bold" color={metric.color}>
                      {metric.value}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                      {metric.label}
                    </Typography>
                  </Box>
                  <Avatar sx={{ bgcolor: metric.bgColor, color: metric.color, width: 56, height: 56 }}>
                    <IconComponent fontSize="large" />
                  </Avatar>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        );
      })}
    </Grid>
  );
}