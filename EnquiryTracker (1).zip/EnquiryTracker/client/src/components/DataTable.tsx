import { Student } from "@shared/schema";
import { Download, RefreshCw } from "lucide-react";
import { useState } from "react";

interface DataTableProps {
  students: Student[];
  totalStudents: number;
  filteredCount: number;
}

export default function DataTable({ students, totalStudents, filteredCount }: DataTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const totalPages = Math.ceil(students.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentStudents = students.slice(startIndex, endIndex);

  const handleExport = () => {
    const csvHeaders = [
      "Student Name",
      "Email",
      "Class Applied",
      "Location",
      "Previous School",
      "Referral Source",
      "Sibling",
      "Lead Score",
      "Category",
      "Application Date"
    ];

    const csvData = students.map(student => [
      student.studentName,
      student.email,
      student.classAppliedFor,
      student.location,
      student.previousSchoolName,
      student.howYouKnowUs,
      student.hasSiblingInSchool ? "Yes" : "No",
      student.leadScore,
      student.leadCategory,
      new Date(student.applicationDate).toLocaleDateString()
    ]);

    const csvContent = [csvHeaders, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "lead_data.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getLeadBadgeClass = (category: string) => {
    switch (category) {
      case "Hot Lead": return "hot";
      case "Warm Lead": return "warm";
      case "Cold Lead": return "cold";
      default: return "";
    }
  };

  const getLeadEmoji = (category: string) => {
    switch (category) {
      case "Hot Lead": return "🔥";
      case "Warm Lead": return "🟡";
      case "Cold Lead": return "❄️";
      default: return "";
    }
  };

  return (
    <div className="data-table-container">
      <div className="table-header">
        <h3 className="table-title">Student Lead Data</h3>
        <div className="action-buttons">
          <button className="btn btn-secondary" onClick={() => window.location.reload()}>
            <RefreshCw size={16} />
            RefreshCw
          </button>
          <button className="btn btn-primary" onClick={handleExport}>
            <Download size={16} />
            Export CSV
          </button>
        </div>
      </div>
      
      <div className="table-responsive">
        <table className="data-grid">
          <thead>
            <tr>
              <th>Student Name</th>
              <th>Class Applied</th>
              <th>Location</th>
              <th>Previous School</th>
              <th>Referral Source</th>
              <th>Sibling</th>
              <th>Lead Score</th>
              <th>Category</th>
              <th>Application Date</th>
            </tr>
          </thead>
          <tbody>
            {currentStudents.map((student) => (
              <tr key={student.id}>
                <td>
                  <strong>{student.studentName}</strong>
                  <br />
                  <small>{student.email}</small>
                </td>
                <td>{student.classAppliedFor}</td>
                <td>{student.location}</td>
                <td>{student.previousSchoolName}</td>
                <td>{student.howYouKnowUs}</td>
                <td>{student.hasSiblingInSchool ? "Yes" : "No"}</td>
                <td>
                  <span className="score-cell">{student.leadScore}</span>
                </td>
                <td>
                  <span className={`lead-badge ${getLeadBadgeClass(student.leadCategory)}`}>
                    {getLeadEmoji(student.leadCategory)} {student.leadCategory}
                  </span>
                </td>
                <td>{new Date(student.applicationDate).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="pagination">
        <div className="pagination-info">
          Showing {startIndex + 1}-{Math.min(endIndex, students.length)} of {filteredCount} records
          {filteredCount !== totalStudents && ` (filtered from ${totalStudents} total)`}
        </div>
        <div className="pagination-controls">
          <button 
            className="page-btn"
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
          >
            ‹
          </button>
          
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            let pageNum;
            if (totalPages <= 5) {
              pageNum = i + 1;
            } else if (currentPage <= 3) {
              pageNum = i + 1;
            } else if (currentPage >= totalPages - 2) {
              pageNum = totalPages - 4 + i;
            } else {
              pageNum = currentPage - 2 + i;
            }
            
            return (
              <button
                key={pageNum}
                className={`page-btn ${currentPage === pageNum ? 'active' : ''}`}
                onClick={() => setCurrentPage(pageNum)}
              >
                {pageNum}
              </button>
            );
          })}
          
          <button 
            className="page-btn"
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
          >
            ›
          </button>
        </div>
      </div>
    </div>
  );
}
