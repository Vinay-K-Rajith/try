import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calculator, User, GraduationCap, MapPin, Phone, Flame, TrendingUp, Snowflake } from "lucide-react";
import { calculateLeadScore, categorizeLeadScore, getLeadCategoryColor, getLeadCategoryEmoji } from "@/lib/leadScoring";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ScoringFormData {
  studentName: string;
  email: string;
  phone: string;
  location: string;
  locationScore: number;
  howYouKnowUs: string;
  howYouKnowUsScore: number;
  hasSiblingInSchool: boolean;
  siblingInSchoolScore: number;
  previousSchoolName: string;
  previousSchoolNameScore: number;
  classAppliedFor: string;
  classAppliedForScore: number;
  lastClassPercentage: string;
  lastClassPercentageScore: number;
  communicationEmailDifferent: boolean;
  communicationEmailDifferentScore: number;
  whatsappNumberDifferent: boolean;
  whatsappNumberDifferentScore: number;
}

const initialFormData: ScoringFormData = {
  studentName: "",
  email: "",
  phone: "",
  location: "",
  locationScore: 0,
  howYouKnowUs: "",
  howYouKnowUsScore: 0,
  hasSiblingInSchool: false,
  siblingInSchoolScore: 0,
  previousSchoolName: "",
  previousSchoolNameScore: 0,
  classAppliedFor: "",
  classAppliedForScore: 0,
  lastClassPercentage: "",
  lastClassPercentageScore: 0,
  communicationEmailDifferent: false,
  communicationEmailDifferentScore: 0,
  whatsappNumberDifferent: false,
  whatsappNumberDifferentScore: 0,
};

export default function IndividualScoring() {
  const [formData, setFormData] = useState<ScoringFormData>(initialFormData);
  const [calculatedScore, setCalculatedScore] = useState<number | null>(null);
  const [calculatedCategory, setCalculatedCategory] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createStudentMutation = useMutation({
    mutationFn: async (studentData: any) => {
      const response = await fetch("/api/students", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(studentData),
      });
      
      if (!response.ok) {
        throw new Error("Failed to create student");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Student lead has been saved successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save student lead. Please try again.",
        variant: "destructive",
      });
    },
  });

  const locationOptions = [
    { label: "Very Close (< 2 km)", value: "Very Close", score: 95 },
    { label: "Close (2-5 km)", value: "Close", score: 85 },
    { label: "Moderate (5-10 km)", value: "Moderate", score: 70 },
    { label: "Far (10-15 km)", value: "Far", score: 50 },
    { label: "Very Far (> 15 km)", value: "Very Far", score: 30 },
  ];

  const knowUsOptions = [
    { label: "Current Parent Referral", value: "Current Parent Referral", score: 95 },
    { label: "Alumni Referral", value: "Alumni Referral", score: 90 },
    { label: "Teacher Referral", value: "Teacher Referral", score: 88 },
    { label: "Friend/Family Referral", value: "Friend/Family Referral", score: 85 },
    { label: "Educational Fair", value: "Educational Fair", score: 75 },
    { label: "Social Media", value: "Social Media", score: 70 },
    { label: "Google Search", value: "Google Search", score: 65 },
    { label: "School Website", value: "School Website", score: 60 },
    { label: "Brochure/Pamphlet", value: "Brochure/Pamphlet", score: 55 },
    { label: "Newspaper Ad", value: "Newspaper Ad", score: 50 },
    { label: "Hoarding/Banner", value: "Hoarding/Banner", score: 45 },
    { label: "Walk-in", value: "Walk-in", score: 40 },
  ];

  const siblingOptions = [
    { label: "Yes - Currently studying", value: "Yes - Currently studying", score: 100 },
    { label: "Yes - Alumni", value: "Yes - Alumni", score: 80 },
    { label: "No", value: "No", score: 0 },
  ];

  const schoolOptions = [
    { label: "Top Tier (DPS, Modern, St. Xavier's)", value: "Top Tier School", score: 90 },
    { label: "High Quality (Ryan, DAV, Amity)", value: "High Quality School", score: 75 },
    { label: "Good (Local Reputed Schools)", value: "Good School", score: 60 },
    { label: "Average (Local Schools)", value: "Average School", score: 45 },
    { label: "Below Average", value: "Below Average School", score: 30 },
  ];

  const classOptions = [
    { label: "Class 11 (Science/Commerce)", value: "Class 11", score: 95 },
    { label: "Class 9", value: "Class 9", score: 90 },
    { label: "Class 6", value: "Class 6", score: 85 },
    { label: "Class 1", value: "Class 1", score: 85 },
    { label: "UKG", value: "UKG", score: 80 },
    { label: "LKG", value: "LKG", score: 75 },
    { label: "Nursery", value: "Nursery", score: 70 },
    { label: "Other Classes", value: "Other", score: 70 },
  ];

  const percentageOptions = [
    { label: "90% and above", value: "90%+", score: 95 },
    { label: "80-89%", value: "80-89%", score: 80 },
    { label: "70-79%", value: "70-79%", score: 65 },
    { label: "60-69%", value: "60-69%", score: 50 },
    { label: "Below 60%", value: "<60%", score: 30 },
    { label: "Not Applicable (Early Classes)", value: "N/A", score: 75 },
  ];

  const handleSelectChange = (field: keyof ScoringFormData, value: string, score: number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      [`${field}Score`]: score,
    }));
  };

  const handleBooleanChange = (field: keyof ScoringFormData, value: string, score: number) => {
    const boolValue = value.includes("Yes");
    setFormData(prev => ({
      ...prev,
      [field]: boolValue,
      [`${field}Score`]: score,
    }));
  };

  const calculateScore = () => {
    const score = calculateLeadScore(
      formData.locationScore,
      formData.howYouKnowUsScore,
      formData.siblingInSchoolScore,
      formData.previousSchoolNameScore,
      formData.classAppliedForScore,
      formData.lastClassPercentageScore,
      formData.communicationEmailDifferentScore,
      formData.whatsappNumberDifferentScore
    );
    
    const category = categorizeLeadScore(score);
    setCalculatedScore(score);
    setCalculatedCategory(category);
  };

  const handleSave = async () => {
    if (!formData.studentName || !formData.email || !calculatedScore) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields and calculate the score first.",
        variant: "destructive",
      });
      return;
    }

    const studentData = {
      studentName: formData.studentName,
      email: formData.email,
      phone: formData.phone || "+91-0000000000",
      location: formData.location,
      locationScore: formData.locationScore,
      howYouKnowUs: formData.howYouKnowUs,
      howYouKnowUsScore: formData.howYouKnowUsScore,
      hasSiblingInSchool: formData.hasSiblingInSchool,
      siblingInSchoolScore: formData.siblingInSchoolScore,
      previousSchoolName: formData.previousSchoolName,
      previousSchoolNameScore: formData.previousSchoolNameScore,
      classAppliedFor: formData.classAppliedFor,
      classAppliedForScore: formData.classAppliedForScore,
      lastClassPercentage: formData.lastClassPercentage || "N/A",
      lastClassPercentageScore: formData.lastClassPercentageScore,
      communicationEmailDifferent: formData.communicationEmailDifferent,
      communicationEmailDifferentScore: formData.communicationEmailDifferentScore,
      whatsappNumberDifferent: formData.whatsappNumberDifferent,
      whatsappNumberDifferentScore: formData.whatsappNumberDifferentScore,
      leadScore: calculatedScore.toString(),
      leadCategory: calculatedCategory,
      applicationDate: new Date(),
    };

    createStudentMutation.mutate(studentData);
  };

  const handleReset = () => {
    setFormData(initialFormData);
    setCalculatedScore(null);
    setCalculatedCategory("");
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Hot Lead": return <Flame className="w-5 h-5" />;
      case "Warm Lead": return <TrendingUp className="w-5 h-5" />;
      case "Cold Lead": return <Snowflake className="w-5 h-5" />;
      default: return null;
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold flex items-center justify-center gap-3 mb-2">
          <Calculator className="w-8 h-8 text-primary" />
          Individual Student Lead Scoring
        </h2>
        <p className="text-muted-foreground">
          Enter student information to get instant lead score and save to database
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Basic Information
            </CardTitle>
            <CardDescription>Student contact details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="studentName">Student Name *</Label>
              <Input
                id="studentName"
                placeholder="e.g., Aarav Sharma"
                value={formData.studentName}
                onChange={(e) => setFormData(prev => ({ ...prev, studentName: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                placeholder="e.g., aarav.sharma@gmail.com"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                placeholder="e.g., +91-9876543210"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
              />
            </div>
          </CardContent>
        </Card>

        {/* Location & Background */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Location & Background
            </CardTitle>
            <CardDescription>Distance and referral information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Distance from School</Label>
              <Select onValueChange={(value) => {
                const option = locationOptions.find(opt => opt.value === value);
                if (option) handleSelectChange('location', option.value, option.score);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select distance range" />
                </SelectTrigger>
                <SelectContent>
                  {locationOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>How did you know about us?</Label>
              <Select onValueChange={(value) => {
                const option = knowUsOptions.find(opt => opt.value === value);
                if (option) handleSelectChange('howYouKnowUs', option.value, option.score);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select referral source" />
                </SelectTrigger>
                <SelectContent>
                  {knowUsOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Sibling in School?</Label>
              <Select onValueChange={(value) => {
                const option = siblingOptions.find(opt => opt.value === value);
                if (option) handleBooleanChange('hasSiblingInSchool', option.value, option.score);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sibling status" />
                </SelectTrigger>
                <SelectContent>
                  {siblingOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Academic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5" />
              Academic Information
            </CardTitle>
            <CardDescription>School and class details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Previous School Category</Label>
              <Select onValueChange={(value) => {
                const option = schoolOptions.find(opt => opt.value === value);
                if (option) handleSelectChange('previousSchoolName', option.value, option.score);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select school category" />
                </SelectTrigger>
                <SelectContent>
                  {schoolOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Class Applied For</Label>
              <Select onValueChange={(value) => {
                const option = classOptions.find(opt => opt.value === value);
                if (option) handleSelectChange('classAppliedFor', option.value, option.score);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Last Class Performance</Label>
              <Select onValueChange={(value) => {
                const option = percentageOptions.find(opt => opt.value === value);
                if (option) handleSelectChange('lastClassPercentage', option.value, option.score);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select performance range" />
                </SelectTrigger>
                <SelectContent>
                  {percentageOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contact Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Contact Information
          </CardTitle>
          <CardDescription>Additional contact preferences</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-4">
          <div>
            <Label>Communication email different from registration?</Label>
            <Select onValueChange={(value) => {
              const score = value === "Yes" ? 65 : 0;
              handleBooleanChange('communicationEmailDifferent', value, score);
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="No">No</SelectItem>
                <SelectItem value="Yes">Yes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>WhatsApp number different from phone?</Label>
            <Select onValueChange={(value) => {
              const score = value === "Yes" ? 55 : 0;
              handleBooleanChange('whatsappNumberDifferent', value, score);
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="No">No</SelectItem>
                <SelectItem value="Yes">Yes</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-center gap-4">
        <Button onClick={calculateScore} size="lg" className="min-w-32">
          <Calculator className="w-4 h-4 mr-2" />
          Calculate Score
        </Button>
        
        <Button 
          onClick={handleSave} 
          variant="default" 
          size="lg" 
          className="min-w-32"
          disabled={!calculatedScore || createStudentMutation.isPending}
        >
          {createStudentMutation.isPending ? "Saving..." : "Save Lead"}
        </Button>
        
        <Button onClick={handleReset} variant="outline" size="lg" className="min-w-32">
          Reset Form
        </Button>
      </div>

      {/* Results */}
      {calculatedScore !== null && (
        <Card className="max-w-md mx-auto">
          <CardHeader className="text-center">
            <CardTitle>Lead Score Result</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="text-6xl font-bold font-mono" style={{ color: getLeadCategoryColor(calculatedCategory) }}>
              {calculatedScore}
            </div>
            
            <Badge 
              variant="secondary" 
              className="text-lg px-4 py-2 flex items-center justify-center gap-2 w-fit mx-auto"
              style={{ 
                backgroundColor: `${getLeadCategoryColor(calculatedCategory)}20`,
                color: getLeadCategoryColor(calculatedCategory),
                border: `1px solid ${getLeadCategoryColor(calculatedCategory)}40`
              }}
            >
              {getCategoryIcon(calculatedCategory)}
              {getLeadCategoryEmoji(calculatedCategory)} {calculatedCategory}
            </Badge>
            
            <p className="text-sm text-muted-foreground">
              {calculatedCategory === "Hot Lead" && "High probability of enrollment - prioritize follow-up"}
              {calculatedCategory === "Warm Lead" && "Good potential - maintain regular contact"}
              {calculatedCategory === "Cold Lead" && "Lower priority - nurture with general communications"}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}