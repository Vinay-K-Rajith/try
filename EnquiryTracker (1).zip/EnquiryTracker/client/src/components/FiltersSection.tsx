interface Filters {
  search: string;
  category: string;
  class: string;
  scoreRange: string;
}

interface FiltersSectionProps {
  filters: Filters;
  onFiltersChange: (filters: Filters) => void;
}

export default function FiltersSection({ filters, onFiltersChange }: FiltersSectionProps) {
  const handleFilterChange = (key: keyof Filters, value: string) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <div className="filters-container">
      <div className="filters-grid">
        <div className="filter-group">
          <label className="filter-label">Search Student</label>
          <input
            type="text"
            className="filter-input"
            placeholder="Search by name, email..."
            value={filters.search}
            onChange={(e) => handleFilterChange('search', e.target.value)}
          />
        </div>
        
        <div className="filter-group">
          <label className="filter-label">Lead Category</label>
          <select
            className="filter-input"
            value={filters.category}
            onChange={(e) => handleFilterChange('category', e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="hot">🔥 Hot Leads</option>
            <option value="warm">🟡 Warm Leads</option>
            <option value="cold">❄️ Cold Leads</option>
          </select>
        </div>
        
        <div className="filter-group">
          <label className="filter-label">Class Applied</label>
          <select
            className="filter-input"
            value={filters.class}
            onChange={(e) => handleFilterChange('class', e.target.value)}
          >
            <option value="">All Classes</option>
            <option value="nursery">Nursery</option>
            <option value="lkg">LKG</option>
            <option value="ukg">UKG</option>
            <option value="class 1">Class 1</option>
            <option value="class 6">Class 6</option>
            <option value="class 9">Class 9</option>
            <option value="class 11">Class 11</option>
          </select>
        </div>
        
        <div className="filter-group">
          <label className="filter-label">Score Range</label>
          <select
            className="filter-input"
            value={filters.scoreRange}
            onChange={(e) => handleFilterChange('scoreRange', e.target.value)}
          >
            <option value="">All Scores</option>
            <option value="90-100">90-100</option>
            <option value="80-89">80-89</option>
            <option value="70-79">70-79</option>
            <option value="60-69">60-69</option>
            <option value="0-59">Below 60</option>
          </select>
        </div>
      </div>
    </div>
  );
}
