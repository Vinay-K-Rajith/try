import { Grid, Card, CardContent, Typography, Box } from '@mui/material';
import { PieChart, BarChart } from '@mui/x-charts';

interface Analytics {
  totalLeads: number;
  hotLeads: number;
  warmLeads: number;
  coldLeads: number;
  scoreDistribution: Record<string, number>;
  classDistribution: Record<string, number>;
  averageScore: number;
}

interface ChartsSectionProps {
  analytics?: Analytics;
}

export default function ChartsSection({ analytics }: ChartsSectionProps) {
  if (!analytics) return null;

  // Prepare data for score distribution bar chart
  const scoreLabels = Object.keys(analytics.scoreDistribution);
  const scoreValues = Object.values(analytics.scoreDistribution);

  // Prepare data for lead categories pie chart
  const categoryData = [
    { id: 0, value: analytics.hotLeads, label: 'Hot Leads' },
    { id: 1, value: analytics.warmLeads, label: 'Warm Leads' },
    { id: 2, value: analytics.coldLeads, label: 'Cold Leads' },
  ];

  return (
    <Grid container spacing={3} sx={{ mb: 4 }}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" component="h3" gutterBottom>
              Lead Score Distribution
            </Typography>
            <Box sx={{ height: 350, width: '100%' }}>
              <BarChart
                xAxis={[
                  {
                    scaleType: 'band',
                    data: scoreLabels,
                  },
                ]}
                series={[
                  {
                    data: scoreValues,
                    color: '#1976d2',
                  },
                ]}
                height={350}
              />
            </Box>
          </CardContent>
        </Card>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" component="h3" gutterBottom>
              Lead Categories
            </Typography>
            <Box sx={{ height: 350, width: '100%' }}>
              <PieChart
                series={[
                  {
                    data: categoryData,
                    highlightScope: { faded: 'global', highlighted: 'item' },
                    faded: { innerRadius: 30, additionalRadius: -30, color: 'gray' },
                  },
                ]}
                height={350}
                colors={['#ff4444', '#ff9800', '#2196f3']}
              />
            </Box>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
}