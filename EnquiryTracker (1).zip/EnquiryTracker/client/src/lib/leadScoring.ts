export interface LeadScoreWeights {
  location: number;
  howYouKnowUs: number;
  siblingInSchool: number;
  previousSchool: number;
  classAppliedFor: number;
  lastClassPercentage: number;
  communicationEmailDifferent: number;
  whatsappNumberDifferent: number;
}

export const DEFAULT_WEIGHTS: LeadScoreWeights = {
  location: 0.85,
  howYouKnowUs: 0.70,
  siblingInSchool: 0.95,
  previousSchool: 0.55,
  classAppliedFor: 0.50,
  lastClassPercentage: 0.25,
  communicationEmailDifferent: 0.25,
  whatsappNumberDifferent: 0.20
};

export function calculateLeadScore(
  locationScore: number,
  howYouKnowUsScore: number,
  siblingInSchoolScore: number,
  previousSchoolScore: number,
  classAppliedForScore: number,
  lastClassPercentageScore: number,
  communicationEmailDifferentScore: number,
  whatsappNumberDifferentScore: number,
  weights: LeadScoreWeights = DEFAULT_WEIGHTS
): number {
  const scores = [
    locationScore,
    howYouKnowUsScore,
    siblingInSchoolScore,
    previousSchoolScore,
    classAppliedForScore,
    lastClassPercentageScore,
    communicationEmailDifferentScore,
    whatsappNumberDifferentScore
  ];

  const weightValues = Object.values(weights);
  const weightedSum = scores.reduce((sum, score, index) => sum + score * weightValues[index], 0);
  const totalWeights = weightValues.reduce((sum, weight) => sum + weight, 0);

  return Math.round((weightedSum / totalWeights + 5) * 100) / 100;
}

export function categorizeLeadScore(score: number): string {
  if (score >= 80) return "Hot Lead";
  if (score >= 60) return "Warm Lead";
  return "Cold Lead";
}

export function getLeadCategoryColor(category: string): string {
  switch (category) {
    case "Hot Lead": return "#ff4444";
    case "Warm Lead": return "#ff9800";
    case "Cold Lead": return "#2196f3";
    default: return "#808080";
  }
}

export function getLeadCategoryEmoji(category: string): string {
  switch (category) {
    case "Hot Lead": return "🔥";
    case "Warm Lead": return "🟡";
    case "Cold Lead": return "❄️";
    default: return "";
  }
}
