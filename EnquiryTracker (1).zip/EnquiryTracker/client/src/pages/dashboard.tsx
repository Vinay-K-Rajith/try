import LeadScoringDashboard from "@/components/LeadScoringDashboard";

export default function Dashboard() {
  return <LeadScoringDashboard />;
}
