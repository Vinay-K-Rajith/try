import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  location: text("location").notNull(),
  locationScore: integer("location_score").notNull(),
  howYouKnowUs: text("how_you_know_us").notNull(),
  howYouKnowUsScore: integer("how_you_know_us_score").notNull(),
  hasSiblingInSchool: boolean("has_sibling_in_school").notNull(),
  siblingInSchoolScore: integer("sibling_in_school_score").notNull(),
  previousSchoolName: text("previous_school_name").notNull(),
  previousSchoolNameScore: integer("previous_school_name_score").notNull(),
  classAppliedFor: text("class_applied_for").notNull(),
  classAppliedForScore: integer("class_applied_for_score").notNull(),
  lastClassPercentage: text("last_class_percentage"),
  lastClassPercentageScore: integer("last_class_percentage_score").notNull(),
  communicationEmailDifferent: boolean("communication_email_different").notNull(),
  communicationEmailDifferentScore: integer("communication_email_different_score").notNull(),
  whatsappNumberDifferent: boolean("whatsapp_number_different").notNull(),
  whatsappNumberDifferentScore: integer("whatsapp_number_different_score").notNull(),
  leadScore: decimal("lead_score", { precision: 5, scale: 2 }).notNull(),
  leadCategory: text("lead_category").notNull(),
  applicationDate: timestamp("application_date").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;
